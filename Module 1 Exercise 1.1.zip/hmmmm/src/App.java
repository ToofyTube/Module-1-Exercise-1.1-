public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Welcome to Java, Welcome to Computer Science and Programming is fun");
    }
}
